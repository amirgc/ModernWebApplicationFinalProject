import { Component, OnInit } from '@angular/core';
import { DishService } from './dish.service';

@Component({
  selector: 'app-dish',
  templateUrl: './dish.component.html',
  styleUrls: ['./dish.component.scss']
})
export class DishComponent implements OnInit {

  categories: String[] = ['Main Dish', 'Bevarage', 'Dessert'];
  constructor(private dishService: DishService) { }

  ngOnInit() {
  }

  onSubmit(f) {
    console.log('onSubmit -- ');
    console.log(f.value);
    
    this.dishService.createDish(f.value).subscribe(result => {
      console.log(result);
    })
    return false;
  }

}
